"""Tests for ZATCA Compliance Monitor"""
